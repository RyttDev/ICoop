<?php

namespace App\Http\Controllers;

use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class InvoiceController extends Controller
{
    public function index(): View
    {
        return view('invoices.index', ['invoices' => DB::table('invoices')->join('members', 'members.id', '=', 'invoices.member_id')->select('invoices.*', 'members.full_name')->latest('issue_date')->get(), 'members' => DB::table('members')->where('status', 'active')->orderBy('full_name')->get()]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate(['document_type' => ['required', 'in:invoice,quotation'], 'member_id' => ['required', 'exists:members,id'], 'attention_to' => ['nullable', 'string', 'max:255'], 'issue_date' => ['required', 'date'], 'due_date' => ['nullable', 'date'], 'items' => ['required', 'array', 'min:1'], 'items.*.description' => ['required', 'string', 'max:255'], 'items.*.quantity' => ['required', 'numeric', 'min:0.01'], 'items.*.unit_price' => ['required', 'numeric', 'min:0.01'], 'notes' => ['nullable', 'string']]);
        $total = collect($data['items'])->sum(fn ($item) => (float) $item['quantity'] * (float) $item['unit_price']);
        $id = DB::transaction(function () use ($data, $total) {
            $prefix = $data['document_type'] === 'quotation' ? 'QT' : 'INV';
            $id = DB::table('invoices')->insertGetId(['invoice_no' => $prefix.'-'.now()->format('Y').'-'.str_pad((string) ((int) DB::table('invoices')->max('id') + 1), 4, '0', STR_PAD_LEFT), 'document_type' => $data['document_type'], 'member_id' => $data['member_id'], 'attention_to' => $data['attention_to'], 'issue_date' => $data['issue_date'], 'due_date' => $data['due_date'], 'subtotal' => $total, 'discount' => 0, 'total' => $total, 'status' => 'issued', 'notes' => $data['notes'], 'created_by' => DB::table('users')->value('id'), 'created_at' => now(), 'updated_at' => now()]);
            foreach ($data['items'] as $item) {
                $amount = $item['quantity'] * $item['unit_price'];
                DB::table('invoice_items')->insert(['invoice_id' => $id, 'description' => $item['description'], 'quantity' => $item['quantity'], 'unit_price' => $item['unit_price'], 'amount' => $amount, 'created_at' => now(), 'updated_at' => now()]);
            }

            return $id;
        });

        return redirect()->route('invoices.index')->with('success', ucfirst($data['document_type'])." #{$id} berjaya dicipta.");
    }

    public function pdf(int $invoice)
    {
        $data = ['invoice' => DB::table('invoices')->join('members', 'members.id', '=', 'invoices.member_id')->where('invoices.id', $invoice)->select('invoices.*', 'members.full_name', 'members.member_no', 'members.address', 'members.email', 'members.phone')->firstOrFail(), 'items' => DB::table('invoice_items')->where('invoice_id', $invoice)->get(), 'settings' => DB::table('cooperative_settings')->first()];

        return Pdf::loadView('invoices.pdf', $data)->setPaper('a4')->download($data['invoice']->invoice_no.'.pdf');
    }
}
